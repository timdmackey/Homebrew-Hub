===========================
Mad Stick 2 (Assembly 2008)
===========================

INDEX

1. PREREQUESTIES
1.1 Xbox 360
2. CONTROLS AND INSTRUCTIONS
2.1 Main Menu
2.2 Game
3. VERSION HISTORY
3.1 Alpha
4. CREDITS

-------------------------

1. PREREQUESTIES

1.1 Xbox 360

- Visual C# 2005 Express Edition SP1
- XNA Game Studio Express 2.0
- XNA Creators Club Accout
- XNA Game Studio Connect

-------------------------

2. CONTROLS AND INSTRUCTIONS

2.1 Main Menu
- Move in the menu using the dpad up and down and accept selection by pressing A button
- Singe player starts the game
- Multi player not yet implemented
- Difficulty changes computer's skill level between novice, normal and expert
- Vibration toggles controller's vibration effects on and off
- Safe area changes safe area between none, small and large
- Exit quits the game

2.3 Game
- Move your player and goalie using the left thumb stick
- Change the way your player is facing using the right thumb stick
- Shoot using left or right trigger
- Press start button to toggle pause
- Press back button to abort the game and return to Main Menu

-------------------------

3. VERSION HISTORY

3.1 Alpha
- First (almost unplayable) version

-------------------------

4. CREDITS

Code 		- Siffo
Graphics	- Peeba

-------------------------