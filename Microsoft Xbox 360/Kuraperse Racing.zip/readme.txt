Kuraperseracing, version Assy2009 ALPHA

You have to press start at the loading screen so that your controller
will be registered to the game. After that the main menu shows up.

This version still lacks much of the content, but a deadline is a deadline ;).
We'll be updating the package whenever possible, stay tuned.

And see you all at Assembly Summer 2009!

masentaa/ElectricApe